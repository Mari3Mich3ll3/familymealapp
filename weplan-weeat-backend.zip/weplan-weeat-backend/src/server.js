// Load environment variables from .env file
require('dotenv').config();

// Import the express app
const app = require('./app');

// Get the port from environment variables or use 5000 as default
const PORT = process.env.PORT || 5000;

// Start the server and listen for incoming requests
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
