// Import express to create a router
const express = require('express');
const router = express.Router();

// Import the family controller functions
const familyController = require('../controllers/familyController');

// Route to add a family member (POST /api/family/add)
router.post('/add', familyController.addFamilyMember);

// Route to get all family members for a user (GET /api/family/:userId)
router.get('/:userId', familyController.getFamilyMembers);

// Export the router for use in app.js
module.exports = router;
