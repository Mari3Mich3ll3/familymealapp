const express = require('express');
const router = express.Router();
const templateController = require('../controllers/templateController');

// POST /api/templates/save
router.post('/save', templateController.saveTemplate);

// GET /api/templates/:userId
router.get('/:userId', templateController.loadTemplates);

module.exports = router;
