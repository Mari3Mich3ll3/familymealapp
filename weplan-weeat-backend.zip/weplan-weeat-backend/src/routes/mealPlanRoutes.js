// Import express and create a router
const express = require('express');
const router = express.Router();

// Import the meal plan controller
const mealPlanController = require('../controllers/mealPlanController');

// Route to generate a meal plan (POST /api/mealplan/generate)
router.post('/generate', mealPlanController.generateMealPlan);

// Export the router
module.exports = router;
