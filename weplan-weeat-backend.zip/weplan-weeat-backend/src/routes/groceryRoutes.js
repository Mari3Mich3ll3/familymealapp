// Import express and create a router
const express = require('express');
const router = express.Router();

// Import the grocery controller
const groceryController = require('../controllers/groceryController');

// Route to generate a grocery list (POST /api/grocery/generate)
router.post('/generate', groceryController.generateGroceryList);

// Export the router
module.exports = router;
