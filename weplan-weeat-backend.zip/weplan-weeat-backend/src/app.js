// Import express and cors for creating the server and handling cross-origin requests
const express = require('express');
const cors = require('cors');

// Import route files for different features
const authRoutes = require('./routes/authRoutes');
const familyRoutes = require('./routes/familyRoutes');
const mealPlanRoutes = require('./routes/mealPlanRoutes');
const groceryRoutes = require('./routes/groceryRoutes');

// Create an express app instance
const app = express();

// Enable CORS to allow requests from the frontend
app.use(cors());

// Parse incoming JSON requests
app.use(express.json());

// Mount the route handlers for each feature under /api/...
app.use('/api/auth', authRoutes);
app.use('/api/family', familyRoutes);
app.use('/api/mealplan', mealPlanRoutes);
app.use('/api/grocery', groceryRoutes);

// Export the app for use in the server entry point
module.exports = app;
