const supabase = require('../services/supabaseService');

// Save a meal template
exports.saveTemplate = async (req, res) => {
  const { userId, name, templateData } = req.body;
  const { data, error } = await supabase
    .from('meal_templates')
    .insert([{ user_id: userId, name, template_data: templateData }]);
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ data });
};

// Load all templates for a user
exports.loadTemplates = async (req, res) => {
  const { userId } = req.params;
  const { data, error } = await supabase
    .from('meal_templates')
    .select('*')
    .eq('user_id', userId);
  if (error) return res.status(400).json({ error: error.message });
  res.status(200).json({ data });
};
