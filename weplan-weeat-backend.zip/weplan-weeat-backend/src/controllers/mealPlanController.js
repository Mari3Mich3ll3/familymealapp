// Import supabase client and geminiService
const supabase = require('../services/supabaseService');
const { getMealPlan } = require('../services/geminiService');

// Controller to generate a meal plan for a user
exports.generateMealPlan = async (req, res) => {
  // Extract userId and family data from the request body
  const { userId, familyData } = req.body;

  try {
    // Get meal plan from Gemini API
    const mealPlan = await getMealPlan(familyData);

    // Save the meal plan in the meal_plans table
    const { data, error } = await supabase
      .from('meal_plans')
      .insert([{ user_id: userId, week_start: new Date(), plan_data: mealPlan }]);

    // If there was an error saving, send a 400 response
    if (error) return res.status(400).json({ error: error.message });

    // Send the meal plan data back to the client
    res.status(201).json({ mealPlan });
  } catch (err) {
    // If there was an error with the Gemini API, send a 500 response
    res.status(500).json({ error: 'Failed to generate meal plan' });
  }
};
