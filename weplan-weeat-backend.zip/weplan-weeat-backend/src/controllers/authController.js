const supabase = require('../services/supabaseService');

// Register a new user
exports.register = async (req, res) => {
  const { email, password } = req.body;
  // Supabase Auth signUp method
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ data });
};

// Login user
exports.login = async (req, res) => {
  const { email, password } = req.body;
  // Supabase Auth signInWithPassword method
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return res.status(400).json({ error: error.message });
  res.status(200).json({ data });
};
