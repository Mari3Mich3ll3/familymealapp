// Import the supabase client
const supabase = require('../services/supabaseService');

// Controller to add a new family member
exports.addFamilyMember = async (req, res) => {
  // Extract the userId, name, age, and healthConditions from the request body
  const { userId, name, age, healthConditions } = req.body;

  // Insert the new family member into the family_members table
  const { data, error } = await supabase
    .from('family_members')
    .insert([{ user_id: userId, name, age, health_conditions: healthConditions }]);

  // If there was an error, send a 400 response with the error message
  if (error) return res.status(400).json({ error: error.message });

  // Otherwise, send a 201 response with the inserted data
  res.status(201).json({ data });
};

// Controller to get all family members for a user
exports.getFamilyMembers = async (req, res) => {
  // Extract userId from the request parameters
  const { userId } = req.params;

  // Select all family members for the given userId
  const { data, error } = await supabase
    .from('family_members')
    .select('*')
    .eq('user_id', userId);

  // If there was an error, send a 400 response with the error message
  if (error) return res.status(400).json({ error: error.message });

  // Otherwise, send a 200 response with the data
  res.status(200).json({ data });
};
